import http from '@/services/http'
import {
  getCompendiumsLineups,
  getCompendiumsLineupsLineupId,
  postCompendiumsLineups,
  patchCompendiumsLineupsLineupId,
  deleteCompendiumsLineupsLineupId,
  postLineupsLineupIdReaction,
  getCharactersCharacterIdLineups,
  getCompendiumsLineupMappings,
  postCompendiumsLineupMappings,
  getCompendiumsLineupMappingsMappingId,
  patchCompendiumsLineupMappingsMappingId,
  postLineupMappingsContainersLineupsReaction,
  deleteAdminLineupMappingsMappingId,
} from '@/services/apifox/NODEJSDEMO/COMPENDIUMLINEUPS/apifox'
import { getCompendiumsCharacters } from '@/services/apifox/NODEJSDEMO/COMPENDIUMS/apifox'
import { getAnonymousId } from '@/utils/anonymous-id'

export type LineupType = string
export type LineupStatus = 'enabled' | 'disabled'

type RawRecord = Record<string, any>

export interface AdminLineupsQuery {
  compendiumId: string
  locale?: string
  keyword?: string
  characterId?: string
  type?: string
  status?: string
  sortBy?: string
  sortOrder?: string
  page?: number
  pageSize?: number
}

export interface AdminLineupsOptionsQuery {
  compendiumId: string
  locale?: string
  keyword?: string
  type?: string
  status?: string
  page?: number
  pageSize?: number
}

export interface AdminLineupsCharacterOptionsQuery {
  compendiumId: string
  locale?: string
  keyword?: string
  status?: string
  page?: number
  pageSize?: number
}

export interface AdminLineupTypesQuery {
  compendiumId: string
}

export interface AdminLineupDetailQuery {
  locale?: string
}

export interface CharacterLineupUsageQuery {
  locale?: string
}

export interface UpdateAdminLineupBody {
  characterIds?: string[]
  description?: string
  name?: string
  status?: LineupStatus
  type?: LineupType
}

export interface CreateAdminLineupBody {
  characterIds: string[]
  compendiumId: string
  description?: string
  name?: string
  status?: LineupStatus
  type: LineupType
}

export interface SaveLineupRelationBody {
  compendiumId?: string
  sourceLineupId: string
  targetLineupIds?: string[]
}

export interface PaginationState {
  page: number
  limit: number
  total: number
  totalPages: number
  hasNext: boolean
  hasPrev: boolean
}

export type ReactionValue = 1 | -1

/** 阵容互动/归属字段（用户侧接口返回）。 */
export interface LineupInteractionFields {
  source: string // 'admin' | 'user'
  createdBy: string | null
  updatedBy: string | null
  likeCount: number
  dislikeCount: number
  score: number
  myReaction: number // 1 赞 / -1 踩 / 0 未表态
  canEdit: boolean
}

export interface ReactionResult {
  id: string
  likeCount: number
  dislikeCount: number
  score: number
  myReaction: number
}

export interface LineupCharacterPreview {
  id: string
  characterId: string
  name: string
  label: string
  avatar: string
  element: string
  elementKey: string
  elementName: string
  archetype: string
  familyKey: string
  familyName: string
  awaken: string
  awakenName: string
  stars: string
}

export interface AdminLineupSummary {
  id: string
  name: string
  type: LineupType | string
  description: string
  status: LineupStatus | string
  memberCount: number
  targetLineupsCount: number
  sourceLineupsCount: number
  characters: LineupCharacterPreview[]
}

export interface AdminLineupListResult {
  items: AdminLineupSummary[]
  pagination: PaginationState
}

export interface UserLineupSummary extends AdminLineupSummary, LineupInteractionFields {}

export interface UserLineupListResult {
  items: UserLineupSummary[]
  pagination: PaginationState
}

export interface LineupOption {
  id: string
  name: string
  type: LineupType | string
  description: string
  status: LineupStatus | string
  memberCount: number
  targetLineupsCount: number
  sourceLineupsCount: number
  characters: LineupCharacterPreview[]
}

export interface LineupTypeOption {
  key: string
  value: string
  label: string
  count: number
}

export interface CharacterOption extends LineupCharacterPreview {
  status: string
}

export interface CharacterOptionResult {
  items: CharacterOption[]
  pagination: PaginationState
}

export interface LineupMemberDetail {
  characterId: string
  familyKey: string
  elementKey: string
  isCore: boolean
  character: LineupCharacterPreview
}

export interface AdminLineupDetail {
  id: string
  name: string
  type: LineupType | string
  description: string
  status: LineupStatus | string
  characters: LineupMemberDetail[]
}

export interface UserLineupDetail extends AdminLineupDetail, LineupInteractionFields {}

export interface RelationDetail {
  sourceLineup: LineupOption | null
  targetLineupIds: string[]
  targetLineups: LineupOption[]
  incomingLineupIds: string[]
  incomingLineups: LineupOption[]
}

export interface PublicLineupReference {
  id: string
  name: string
  type: string
}

export interface PublicLineup extends LineupInteractionFields {
  id: string
  name: string
  type: string
  description: string
  memberCount: number
  targetLineupsCount: number
  sourceLineupsCount: number
  characters: LineupCharacterPreview[]
  targetLineupIds: string[]
  targetLineups: PublicLineupReference[]
  incomingLineupIds: string[]
  incomingLineups: PublicLineupReference[]
}

export interface CharacterLineupUsage {
  lineups: PublicLineup[]
}

const emptyPagination = (): PaginationState => ({
  page: 1,
  limit: 20,
  total: 0,
  totalPages: 0,
  hasNext: false,
  hasPrev: false,
})

const isRecord = (value: unknown): value is RawRecord => typeof value === 'object' && value !== null && !Array.isArray(value)

const toText = (value: unknown): string => {
  if (typeof value === 'string') return value
  if (typeof value === 'number') return String(value)
  if (typeof value === 'boolean') return value ? 'true' : 'false'
  return ''
}

const toNumber = (value: unknown, fallback = 0): number => {
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value === 'string' && value.trim()) {
    const parsed = Number(value)
    if (!Number.isNaN(parsed)) return parsed
  }
  return fallback
}

const normalizeUrl = (url?: string): string => {
  if (!url) return ''
  if (url.startsWith('http://')) return url.replace(/^http:/, 'https:')
  return url
}

const toArray = (value: unknown): unknown[] => (Array.isArray(value) ? value : [])

const sanitizeQuery = <T extends Record<string, any>>(query: T): Partial<T> => {
  const entries = Object.entries(query).filter(([, value]) => value !== undefined && value !== null && value !== '')
  return Object.fromEntries(entries) as Partial<T>
}

const extractData = (res: unknown): RawRecord => {
  if (isRecord(res) && isRecord(res.data)) return res.data
  return (isRecord(res) ? res : {}) as RawRecord
}

/** 给可选认证接口统一带上游客标识头（登录用户也带，后端以 token 为准忽略）。 */
const withAnonymousHeader = (config: Record<string, any> = {}) => ({
  ...config,
  header: { ...(config.header || {}), 'X-Anonymous-Id': getAnonymousId() },
})

const normalizeInteraction = (source: unknown): LineupInteractionFields => {
  const record = isRecord(source) ? source : {}
  return {
    source: toText(record.source) || 'admin',
    createdBy: record.createdBy != null ? toText(record.createdBy) : null,
    updatedBy: record.updatedBy != null ? toText(record.updatedBy) : null,
    likeCount: toNumber(record.likeCount),
    dislikeCount: toNumber(record.dislikeCount),
    score: toNumber(record.score),
    myReaction: toNumber(record.myReaction),
    canEdit: Boolean(record.canEdit),
  }
}

const normalizePagination = (source: unknown): PaginationState => {
  const data = isRecord(source) ? source : {}
  return {
    page: toNumber(data.page, 1),
    limit: toNumber(data.limit ?? data.pageSize, 20),
    total: toNumber(data.total, 0),
    totalPages: toNumber(data.totalPages, 0),
    hasNext: Boolean(data.hasNext),
    hasPrev: Boolean(data.hasPrev),
  }
}

const findCategory = (categories: unknown, key: string): RawRecord => {
  if (!Array.isArray(categories)) return {}
  const found = categories.find((item: unknown) => isRecord(item) && item.key === key)
  return isRecord(found) ? found : {}
}

const findAttribute = (attributes: unknown, key: string): RawRecord => {
  if (!Array.isArray(attributes)) return {}
  const found = attributes.find((item: unknown) => isRecord(item) && (item.key === key || item.name === key))
  return isRecord(found) ? found : {}
}

const normalizeCharacterPreview = (source: unknown): LineupCharacterPreview => {
  const record = isRecord(source) ? source : {}
  const nestedCharacter = isRecord(record.character) ? record.character : {}
  const categories = [...toArray(record.categories), ...toArray(nestedCharacter.categories)]
  const attributes = [...toArray(record.attributes), ...toArray(nestedCharacter.attributes)]

  const familyCat = findCategory(categories, 'family')
  const archetypeCat = findCategory(categories, 'archetype')
  const elementCat = findCategory(categories, 'element')
  const awakenCat = findCategory(categories, 'awaken')
  const starsAttr = findAttribute(attributes, 'stars')

  return {
    id: toText(record.id || nestedCharacter.id || record.characterId),
    characterId: toText(record.characterId || nestedCharacter.id || record.id),
    name: toText(record.name || nestedCharacter.name),
    label: toText(record.label || record.name || nestedCharacter.name),
    avatar: normalizeUrl(toText(record.avatar || nestedCharacter.avatar)),
    element: toText(
      record.element ||
        nestedCharacter.elementKey ||
        record.elementKey ||
        elementCat.valueKey ||
        elementCat.value ||
        nestedCharacter.element ||
        nestedCharacter.elementName,
    ),
    elementKey: toText(record.elementKey || nestedCharacter.elementKey || record.element || elementCat.valueKey || elementCat.value),
    elementName: toText(record.elementName || nestedCharacter.elementName || elementCat.value || elementCat.valueKey),
    archetype: toText(
      record.archetype ||
        record.archetypeKey ||
        record.speciesType ||
        nestedCharacter.archetype ||
        nestedCharacter.archetypeKey ||
        nestedCharacter.speciesType ||
        archetypeCat.valueKey ||
        archetypeCat.value,
    ),
    familyKey: toText(record.familyKey || nestedCharacter.familyKey || familyCat.valueKey),
    familyName: toText(record.familyName || nestedCharacter.familyName || familyCat.value || familyCat.name),
    awaken: toText(record.awaken || nestedCharacter.awaken || awakenCat.value || awakenCat.valueKey),
    awakenName: toText(record.awakenName || nestedCharacter.awakenName || awakenCat.valueKey || awakenCat.value),
    stars: toText(record.stars || nestedCharacter.stars || starsAttr.displayValue || starsAttr.value),
  }
}

const normalizeLineupCharacters = (source: unknown): LineupCharacterPreview[] => toArray(source).map(normalizeCharacterPreview)

const normalizeLineupSummary = (source: unknown): AdminLineupSummary => {
  const record = isRecord(source) ? source : {}
  return {
    id: toText(record.id),
    name: toText(record.name),
    type: toText(record.type),
    description: toText(record.description),
    status: toText(record.status),
    memberCount: toNumber(record.memberCount),
    targetLineupsCount: toNumber(record.targetLineupsCount),
    sourceLineupsCount: toNumber(record.sourceLineupsCount),
    characters: normalizeLineupCharacters(record.characters),
  }
}

const normalizeUserLineupSummary = (source: unknown): UserLineupSummary => {
  const record = isRecord(source) ? source : {}
  return { ...normalizeLineupSummary(record), ...normalizeInteraction(record) }
}

const normalizeLineupOption = (source: unknown): LineupOption => {
  const record = isRecord(source) ? source : {}
  return {
    id: toText(record.id),
    name: toText(record.name),
    type: toText(record.type),
    description: toText(record.description),
    status: toText(record.status),
    memberCount: toNumber(record.memberCount),
    targetLineupsCount: toNumber(record.targetLineupsCount),
    sourceLineupsCount: toNumber(record.sourceLineupsCount),
    characters: normalizeLineupCharacters(record.characters),
  }
}

const normalizeCharacterOption = (source: unknown): CharacterOption => {
  const record = isRecord(source) ? source : {}
  return {
    ...normalizeCharacterPreview(record),
    status: toText(record.status),
  }
}

const normalizeLineupMemberDetail = (source: unknown): LineupMemberDetail => {
  const record = isRecord(source) ? source : {}
  return {
    characterId: toText(record.characterId),
    familyKey: toText(record.familyKey),
    elementKey: toText(record.elementKey),
    isCore: Boolean(record.isCore),
    character: normalizeCharacterPreview(record.character),
  }
}

const normalizeReference = (source: unknown): PublicLineupReference => {
  const record = isRecord(source) ? source : {}
  return {
    id: toText(record.id),
    name: toText(record.name),
    type: toText(record.type),
  }
}

const normalizePublicLineup = (source: unknown): PublicLineup => {
  const record = isRecord(source) ? source : {}
  return {
    id: toText(record.id),
    name: toText(record.name),
    type: toText(record.type),
    description: toText(record.description),
    memberCount: toNumber(record.memberCount),
    targetLineupsCount: toNumber(record.targetLineupsCount),
    sourceLineupsCount: toNumber(record.sourceLineupsCount),
    characters: normalizeLineupCharacters(record.characters),
    targetLineupIds: toArray(record.targetLineupIds)
      .map(item => toText(item))
      .filter(Boolean),
    targetLineups: toArray(record.targetLineups).map(normalizeReference),
    incomingLineupIds: toArray(record.incomingLineupIds)
      .map(item => toText(item))
      .filter(Boolean),
    incomingLineups: toArray(record.incomingLineups).map(normalizeReference),
    ...normalizeInteraction(record),
  }
}

export const fetchAdminLineups = async (query: AdminLineupsQuery): Promise<AdminLineupListResult> => {
  const res = await http.get('/admin/lineups', sanitizeQuery(query), {})
  const data = extractData(res)
  return {
    items: toArray(data.items).map(normalizeLineupSummary),
    pagination: normalizePagination(data.pagination),
  }
}

export const createAdminLineup = async (payload: CreateAdminLineupBody): Promise<AdminLineupDetail> => {
  const res = await http.post('/admin/lineups', payload, {})
  return fetchAdminLineupDetailFromUnknown(res)
}

export const fetchAdminLineupOptions = async (query: AdminLineupsOptionsQuery): Promise<LineupOption[]> => {
  const res = await http.get('/admin/lineups/options', sanitizeQuery(query), {})
  const data = extractData(res)
  const items = Array.isArray(data.items) ? data.items : Array.isArray(res) ? res : []
  return items.map(normalizeLineupOption)
}

export const fetchAdminLineupTypes = async (query: AdminLineupTypesQuery): Promise<LineupTypeOption[]> => {
  const res = await http.get('/admin/lineups/types', sanitizeQuery(query), {})
  const data = extractData(res)
  const items = Array.isArray(data.items) ? data.items : Array.isArray(res) ? res : []
  return items
    .map(item => {
      const record = isRecord(item) ? item : {}
      return {
        key: toText(record.key),
        value: toText(record.value || record.key),
        label: toText(record.label || record.value || record.key),
        count: toNumber(record.count),
      }
    })
    .filter(item => Boolean(item.value))
}

export const fetchAdminCharacterOptions = async (query: AdminLineupsCharacterOptionsQuery): Promise<CharacterOptionResult> => {
  const res = await http.get('/admin/lineups/character-options', sanitizeQuery(query), {})
  const data = extractData(res)
  return {
    items: toArray(data.items).map(normalizeCharacterOption),
    pagination: normalizePagination(data.pagination),
  }
}

export const fetchCharacterOptions = async (query: AdminLineupsCharacterOptionsQuery): Promise<CharacterOptionResult> => {
  const { compendiumId, locale, keyword, page, pageSize } = query
  const res = await getCompendiumsCharacters(sanitizeQuery({ compendiumId, locale, keyword, page, pageSize }) as any, {})
  const data = extractData(res)
  return {
    items: toArray(data.items).map(normalizeCharacterOption),
    pagination: normalizePagination(data.pagination),
  }
}

const fetchAdminLineupDetailFromUnknown = (res: unknown): AdminLineupDetail => {
  const data = extractData(res)
  return {
    id: toText(data.id),
    name: toText(data.name),
    type: toText(data.type),
    description: toText(data.description),
    status: toText(data.status),
    characters: toArray(data.characters).map(normalizeLineupMemberDetail),
  }
}

export const fetchAdminLineupDetail = async (lineupId: string, query: AdminLineupDetailQuery = {}): Promise<AdminLineupDetail> => {
  const res = await http.get(`/admin/lineups/${lineupId}`, query, {})
  return fetchAdminLineupDetailFromUnknown(res)
}

export const updateAdminLineup = async (lineupId: string, payload: UpdateAdminLineupBody): Promise<AdminLineupDetail> => {
  const res = await http.patch(`/admin/lineups/${lineupId}`, payload, {})
  return fetchAdminLineupDetailFromUnknown(res)
}

export const deleteAdminLineup = async (lineupId: string): Promise<void> => {
  await http.delete(`/admin/lineups/${lineupId}`, {}, {})
}

export const fetchLineupRelationDetail = async (sourceLineupId: string, query: AdminLineupDetailQuery = {}): Promise<RelationDetail> => {
  const res = await http.get(`/admin/lineup-relations/${sourceLineupId}`, query, {})
  const data = extractData(res)
  return {
    sourceLineup: isRecord(data.sourceLineup) ? normalizeLineupOption(data.sourceLineup) : null,
    targetLineupIds: toArray(data.targetLineupIds)
      .map(item => toText(item))
      .filter(Boolean),
    targetLineups: toArray(data.targetLineups).map(normalizeLineupOption),
    incomingLineupIds: toArray(data.incomingLineupIds)
      .map(item => toText(item))
      .filter(Boolean),
    incomingLineups: toArray(data.incomingLineups).map(normalizeLineupOption),
  }
}

export const saveLineupRelation = async (payload: SaveLineupRelationBody): Promise<RelationDetail> => {
  const res = await http.post('/admin/lineup-relations', payload, {})
  const data = extractData(res)
  return {
    sourceLineup: isRecord(data.sourceLineup) ? normalizeLineupOption(data.sourceLineup) : null,
    targetLineupIds: toArray(data.targetLineupIds)
      .map(item => toText(item))
      .filter(Boolean),
    targetLineups: toArray(data.targetLineups).map(normalizeLineupOption),
    incomingLineupIds: toArray(data.incomingLineupIds)
      .map(item => toText(item))
      .filter(Boolean),
    incomingLineups: toArray(data.incomingLineups).map(normalizeLineupOption),
  }
}

// ---- 用户侧接口（统一走 apifox 封装方法） ----

const userLineupDetailFromUnknown = (res: unknown): UserLineupDetail => ({
  ...fetchAdminLineupDetailFromUnknown(res),
  ...normalizeInteraction(extractData(res)),
})

export const fetchUserLineups = async (query: AdminLineupsQuery): Promise<UserLineupListResult> => {
  const res = await getCompendiumsLineups(sanitizeQuery(query) as any, withAnonymousHeader())
  const data = extractData(res)
  return {
    items: toArray(data.items).map(normalizeUserLineupSummary),
    pagination: normalizePagination(data.pagination),
  }
}

export const fetchUserLineupDetail = async (lineupId: string, query: AdminLineupDetailQuery = {}): Promise<UserLineupDetail> => {
  const res = await getCompendiumsLineupsLineupId(lineupId, sanitizeQuery(query) as any, withAnonymousHeader())
  return userLineupDetailFromUnknown(res)
}

export const createUserLineup = async (payload: CreateAdminLineupBody): Promise<UserLineupDetail> => {
  const res = await postCompendiumsLineups(payload as any, withAnonymousHeader())
  return userLineupDetailFromUnknown(res)
}

export const updateUserLineup = async (lineupId: string, payload: UpdateAdminLineupBody): Promise<UserLineupDetail> => {
  const res = await patchCompendiumsLineupsLineupId(lineupId, payload as any, withAnonymousHeader())
  return userLineupDetailFromUnknown(res)
}

export const deleteUserLineup = async (lineupId: string): Promise<void> => {
  await deleteCompendiumsLineupsLineupId(lineupId, withAnonymousHeader())
}

export const reactToLineup = async (lineupId: string, value: ReactionValue): Promise<ReactionResult> => {
  const res = await postLineupsLineupIdReaction(lineupId, { value, anonymousId: getAnonymousId() } as any, withAnonymousHeader())
  const data = extractData(res)
  return {
    id: toText(data.id) || lineupId,
    likeCount: toNumber(data.likeCount),
    dislikeCount: toNumber(data.dislikeCount),
    score: toNumber(data.score),
    myReaction: toNumber(data.myReaction),
  }
}

export const fetchCharacterLineupUsage = async (
  characterId: string,
  query: CharacterLineupUsageQuery = {},
): Promise<CharacterLineupUsage> => {
  const res = await getCharactersCharacterIdLineups(characterId, sanitizeQuery(query) as any, withAnonymousHeader())
  const data = extractData(res)

  return {
    lineups: toArray(data.lineups).map(normalizePublicLineup),
  }
}

// ---- 阵容映射（容器化）用户侧接口 ----

export type ContainerKind = 'source' | 'target'

/** 容器内阵容的基本信息（阵容快照）。 */
export interface ContainerLineupInfo {
  id: string
  name: string
  type: string
}

/** 容器内单个阵容（自带独立于全局的互动计数）。 */
export interface LineupMappingContainerItem {
  itemId: string
  lineupId: string
  order: number
  lineup: ContainerLineupInfo | null
  likeCount: number
  dislikeCount: number
  score: number
  myReaction: number
}

/** 映射容器（源/目标），含唯一 containerId 与容器内阵容列表。 */
export interface LineupMappingContainer {
  containerId: string
  items: LineupMappingContainerItem[]
}

export interface LineupMapping {
  id: string
  gameId: string
  name: string
  description: string
  status: string
  sourceContainer: LineupMappingContainer
  targetContainer: LineupMappingContainer
  createdBy: string | null
  canEdit: boolean
  createdAt: string
  updatedAt: string
}

export interface LineupMappingListResult {
  items: LineupMapping[]
  pagination: PaginationState
}

export interface LineupMappingListQuery {
  compendiumId: string
  gameId?: string
  page?: number
  limit?: number
}

export interface CreateLineupMappingBody {
  compendiumId?: string
  gameId?: string
  name?: string
  description?: string
  sourceLineupIds?: string[]
  targetLineupIds?: string[]
}

export interface LineupMappingContainerChange {
  containerId: string
  lineupIds: string[]
}

export interface UpdateLineupMappingBody {
  name?: string
  description?: string
  add?: LineupMappingContainerChange[]
  remove?: LineupMappingContainerChange[]
}

export interface ContainerReactionResult {
  likeCount: number
  dislikeCount: number
  score: number
  myReaction: number
}

const normalizeContainerLineupInfo = (source: unknown): ContainerLineupInfo | null => {
  if (!isRecord(source)) return null
  return {
    id: toText(source.id),
    name: toText(source.name),
    type: toText(source.type),
  }
}

const normalizeContainerItem = (source: unknown): LineupMappingContainerItem => {
  const record = isRecord(source) ? source : {}
  return {
    itemId: toText(record.itemId),
    lineupId: toText(record.lineupId),
    order: toNumber(record.order),
    lineup: normalizeContainerLineupInfo(record.lineup),
    likeCount: toNumber(record.likeCount),
    dislikeCount: toNumber(record.dislikeCount),
    score: toNumber(record.score),
    myReaction: toNumber(record.myReaction),
  }
}

const normalizeContainer = (source: unknown): LineupMappingContainer => {
  const record = isRecord(source) ? source : {}
  return {
    containerId: toText(record.containerId),
    items: toArray(record.items).map(normalizeContainerItem),
  }
}

const normalizeLineupMapping = (source: unknown): LineupMapping => {
  const record = isRecord(source) ? source : {}
  return {
    id: toText(record.id),
    gameId: toText(record.gameId),
    name: toText(record.name),
    description: toText(record.description),
    status: toText(record.status) || 'active',
    sourceContainer: normalizeContainer(record.sourceContainer),
    targetContainer: normalizeContainer(record.targetContainer),
    createdBy: record.createdBy != null ? toText(record.createdBy) : null,
    canEdit: Boolean(record.canEdit),
    createdAt: toText(record.createdAt),
    updatedAt: toText(record.updatedAt),
  }
}

export const fetchLineupMappings = async (query: LineupMappingListQuery): Promise<LineupMappingListResult> => {
  const res = await getCompendiumsLineupMappings(sanitizeQuery(query) as any, withAnonymousHeader())
  const data = extractData(res)
  return {
    items: toArray(data.items).map(normalizeLineupMapping),
    pagination: normalizePagination(data),
  }
}

export const createLineupMapping = async (payload: CreateLineupMappingBody): Promise<LineupMapping> => {
  const res = await postCompendiumsLineupMappings(sanitizeQuery(payload) as any, withAnonymousHeader())
  return normalizeLineupMapping(extractData(res))
}

export const fetchLineupMappingDetail = async (mappingId: string): Promise<LineupMapping> => {
  const res = await getCompendiumsLineupMappingsMappingId(mappingId, withAnonymousHeader())
  return normalizeLineupMapping(extractData(res))
}

export const updateLineupMapping = async (mappingId: string, payload: UpdateLineupMappingBody): Promise<LineupMapping> => {
  const res = await patchCompendiumsLineupMappingsMappingId(mappingId, payload as any, withAnonymousHeader())
  return normalizeLineupMapping(extractData(res))
}

/** 删除映射：仅管理员，走管理侧软删除接口。 */
export const deleteLineupMapping = async (mappingId: string): Promise<void> => {
  await deleteAdminLineupMappingsMappingId(mappingId, withAnonymousHeader())
}

/** 容器内阵容点赞/点踩（便捷路由），返回该容器内该阵容的独立计数。 */
export const reactToContainerLineup = async (
  mappingId: string,
  containerId: string,
  lineupId: string,
  value: ReactionValue,
): Promise<ContainerReactionResult> => {
  const res = await postLineupMappingsContainersLineupsReaction({ mappingId, containerId, lineupId }, { value }, withAnonymousHeader())
  const data = extractData(res)
  return {
    likeCount: toNumber(data.likeCount),
    dislikeCount: toNumber(data.dislikeCount),
    score: toNumber(data.score),
    myReaction: toNumber(data.myReaction),
  }
}

export const hasPaginationNextPage = (pagination?: PaginationState | null): boolean => Boolean(pagination && pagination.hasNext)

export const getPaginationOrDefault = (pagination?: PaginationState | null): PaginationState => pagination || emptyPagination()
