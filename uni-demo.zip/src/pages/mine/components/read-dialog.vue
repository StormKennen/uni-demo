<script setup lang="ts">
  import { PrivacyPageUrl, ProtocolPageUrl } from '@/utils/const'
  import { ref } from 'vue'
  type Props = {
    confirm: () => void
    cancel?: () => void
  }
  const props = defineProps<Props>()
  const change = () => {
    console.log('change')
  }
  const popup = ref(null)
  const open = () => {
    popup.value?.open('center')
  }
  const onAgree = () => {
    props.confirm()
    popup.value?.close()
  }
  const onCancel = () => {
    props.cancel?.()
    popup.value?.close()
  }
  const onPrivacy = () => {
    uni.navigateTo({
      url: PrivacyPageUrl,
    })
  }
  const onProtocol = () => {
    uni.navigateTo({
      url: ProtocolPageUrl,
    })
  }

  defineExpose({
    open,
  })
</script>

<template>
  <view class="read-dialog">
    <uni-popup ref="popup" background-color="transparent" border-radius="12rpx" @change="change">
      <view class="popup-content">
        <view class="top" hover-class="none" hover-stop-propagation="false">
          <text class=""> 请先阅读并同意<text @click="onPrivacy" class="protocol">《隐私政策》</text> </text>
          <br />
          <text class=""> 和<text class="protocol" @click="onProtocol">《用户服务协议》</text> </text>
        </view>
        <view class="bottom" hover-class="none" hover-stop-propagation="false">
          <button class="btn cancel-btn" @click="onCancel">返回</button>
          <button class="btn agree-btn" @click="onAgree">同意</button>
        </view>
      </view>
    </uni-popup>
  </view>
</template>

<style lang="scss" scoped>
  .read-dialog {
    .protocol {
      color: var(--theme-brand);
      font-size: 30rpx;
      font-weight: 500;
    }
    .popup-content {
      padding: 72rpx 32rpx 48rpx;
      width: 606rpx;
      height: 344rpx;
      box-sizing: border-box;
      border: 1rpx solid var(--theme-border);
      border-radius: 18rpx;
      background: var(--theme-surface);
      .top {
        text-align: center;
        font-size: 30rpx;
        color: var(--theme-text);
      }
      .bottom {
        display: flex;
        margin-top: 48rpx;
        justify-content: space-between;
        .btn {
          width: 262rpx;
          height: 92rpx;
          line-height: 92rpx;
          text-align: center;
          border-radius: 6rpx;
          font-size: 32rpx;
          font-weight: 500;
          &::after {
            display: none;
          }
        }
        .cancel-btn {
          background: var(--theme-surface-2);
          color: var(--theme-text-secondary);
        }
        .agree-btn {
          background: var(--theme-brand);
          color: #fff;
        }
      }
    }
  }
</style>
